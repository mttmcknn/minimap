"""Bounded old/new drawer diagnostic; never use these wrapped timings as a speed claim."""
import datetime
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import sys
from types import SimpleNamespace

ROOT = Path('/private/tmp/minimap-performance-20260922')
HARNESS = ROOT / 'candidate-06/source/evals'
sys.path.insert(0, str(HARNESS))
from paired_navigation import PairedEval, SAMPLES, verifies
from replay_performance import graph_digest


PROXY = r'''import json, os, pathlib, subprocess, sys, time
root = pathlib.Path(os.environ['MM_TRACE_DIR'])
tool = pathlib.Path(sys.argv[0]).name
start = time.perf_counter()
stamp = str(time.time_ns()) + '-' + str(os.getpid()) + '-' + tool
try:
    result = subprocess.run([os.environ['MM_REAL_' + tool.upper()], *sys.argv[1:]], capture_output=True, timeout=45)
except subprocess.TimeoutExpired as error:
    result = subprocess.CompletedProcess(sys.argv, 124, error.stdout or b'', error.stderr or b'')
row = {'phase': os.environ['MM_TRACE_PHASE'], 'tool': tool, 'args': sys.argv[1:],
       'seconds': time.perf_counter() - start, 'status': result.returncode,
       'stdout': stamp + '.stdout', 'stderr': stamp + '.stderr'}
(root / row['stdout']).write_bytes(result.stdout)
(root / row['stderr']).write_bytes(result.stderr)
fd = os.open(root / 'calls.jsonl', os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
try:
    os.write(fd, (json.dumps(row) + '\n').encode())
finally:
    os.close(fd)
sys.stdout.buffer.write(result.stdout)
sys.stderr.buffer.write(result.stderr)
sys.exit(result.returncode)
'''


class DrawerEval(PairedEval):
    def run(self, phase, argv, cwd=None, check=True):
        self.env['MM_TRACE_PHASE'] = phase
        return super().run(phase, argv, cwd, check)

    def save(self):
        report = {'metadata': self.metadata, 'trials': self.results, 'calls': self.calls}
        (self.output / 'results.json').write_text(json.dumps(report, indent=2) + '\n')


def main():
    assert not json.loads((ROOT / 'STATE.json').read_text())['batch_running'], 'Another device cohort is still running'
    args = SimpleNamespace(output=ROOT / 'diagnostic-drawer-06-api36',
        binary=ROOT / 'candidate-06/minimap', apk=ROOT / 'apks/jetnews-baseline.apk',
        serial='emulator-5556', repetitions=3, startup_seconds=30)
    evaluation = DrawerEval(args)
    spec = {**SAMPLES['jetnews'], 'apk': args.apk}
    trace = evaluation.output / 'trace'
    trace.mkdir()
    proxy = evaluation.output / 'proxy'
    proxy.mkdir()
    for tool in ('adb', 'android'):
        evaluation.env['MM_REAL_' + tool.upper()] = shutil.which(tool)
        assert evaluation.env['MM_REAL_' + tool.upper()]
        script = proxy / tool
        script.write_text('#!' + sys.executable + '\n' + PROXY)
        script.chmod(0o700)
    plain_path = evaluation.env['PATH']
    trace_path = str(proxy) + os.pathsep + plain_path
    evaluation.env['MM_TRACE_DIR'] = str(trace)
    setting = ['adb', '-s', args.serial, 'shell', 'settings']
    original = evaluation.run('environment', [*setting, 'get', 'global', 'animator_duration_scale']).strip()
    assert original == 'null' or (math.isfinite(float(original)) and float(original) >= 0)
    if original != 'null':
        assert all(char in '0123456789.eE+-' for char in original)
    binaries = {name: ROOT / name / 'minimap' for name in ('candidate-05', 'candidate-06')}
    evaluation.metadata.update({
        'suite': 'drawer-stability-diagnostic', 'planned_trials': 12,
        'created_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'original_animator_duration_scale': original,
        'binary_sha256_by_arm': {name: hashlib.sha256(p.read_bytes()).hexdigest() for name, p in binaries.items()},
        'seed_graph_sha256': graph_digest(ROOT / 'confirmation-api36/seed-jetnews'),
        'profile_overhead_included': True, 'speed_claim_eligible': False,
        'note': 'A small diagnostic, not a reliability estimate; the moving-drawer cause is a hypothesis until traced.',
        'settings_restored': False,
    })
    evaluation.save()
    try:
        for label, scale in (('normal', original), ('slow', '5')):
            if scale == 'null':
                evaluation.run('fixture-setting', [*setting, 'delete', 'global', 'animator_duration_scale'])
            else:
                evaluation.run('fixture-setting', [*setting, 'put', 'global', 'animator_duration_scale', scale])
            observed = evaluation.run('fixture-setting', [*setting, 'get', 'global', 'animator_duration_scale']).strip()
            assert observed == scale or (scale != 'null' and float(observed) == float(scale))
            for repeat in range(1, 4):
                arms = list(binaries)
                if repeat % 2 == 0:
                    arms.reverse()
                for arm in arms:
                    phase = f'{label}-{repeat}-{arm}'
                    row = {'phase': phase, 'arm': arm, 'repeat': repeat, 'scale': scale,
                           'setup_passed': False, 'reported_ok': False, 'oracle_reached_target': None, 'error': None}
                    repo = evaluation.copy_graph(ROOT / 'confirmation-api36/seed-jetnews', phase)
                    before = graph_digest(repo)
                    try:
                        evaluation.restart(spec, 'setup-' + phase)
                        row['setup_passed'] = True
                        args.binary = binaries[arm]
                        evaluation.env['PATH'] = trace_path
                        result = evaluation.go(phase, repo, spec)
                        row['status'] = result['status']
                        row['reported_ok'] = result['status'] == 'ok'
                    except Exception as error:
                        row['error'] = str(error)
                    finally:
                        evaluation.env['PATH'] = plain_path
                    if row['setup_passed']:
                        try:
                            row['oracle_reached_target'] = verifies(evaluation.android_layout('oracle-' + phase), spec['checks'])
                        except Exception as error:
                            row['oracle_error'] = str(error)
                    row.update(evaluation.measure(phase))
                    row['graph_unchanged'] = before == graph_digest(repo)
                    row['false_success'] = row['reported_ok'] and row['oracle_reached_target'] is False
                    row['success'] = bool(row['setup_passed'] and row['reported_ok'] and row['oracle_reached_target'] and row['graph_unchanged'] and not row['error'])
                    evaluation.results.append(row)
                    evaluation.save()
                    print(json.dumps(row), flush=True)
    finally:
        evaluation.env['PATH'] = plain_path
        if original == 'null':
            evaluation.run('restore-setting', [*setting, 'delete', 'global', 'animator_duration_scale'])
        else:
            evaluation.run('restore-setting', [*setting, 'put', 'global', 'animator_duration_scale', original])
        restored = evaluation.run('restore-setting', [*setting, 'get', 'global', 'animator_duration_scale']).strip()
        evaluation.metadata['settings_restored'] = restored == original or (original != 'null' and float(restored) == float(original))
        evaluation.save()
    assert evaluation.metadata['settings_restored']
    assert len(evaluation.results) == 12
    assert all(row['success'] for row in evaluation.results if row['arm'] == 'candidate-06')


if __name__ == '__main__':
    main()
