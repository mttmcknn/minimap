"""Record host-sleep and clock-continuity evidence after the full cohort finishes."""
import datetime
import json
from pathlib import Path
import subprocess

ROOT = Path('/private/tmp/minimap-performance-20260922')
records = json.loads((ROOT / 'confirmation-06-plan/execution-awake.json').read_text())
records = [record for record in records if record['stage'].startswith('confirmation-awake-api')]
assert {record['stage'] for record in records} == {'confirmation-awake-api36', 'confirmation-awake-api37'}
parse = datetime.datetime.fromisoformat
start = min(parse(record['started_at']) for record in records)
finish = max(parse(record['finished_at']) for record in records)
power = subprocess.run(['/usr/bin/pmset', '-g', 'log'], capture_output=True, text=True, check=True, timeout=20)
events = []
for line in power.stdout.splitlines():
    if not any(word in line for word in ('Entering Sleep', 'Wake from', 'DarkWake from')):
        continue
    try:
        instant = datetime.datetime.strptime(line[:25], '%Y-%m-%d %H:%M:%S %z')
    except ValueError:
        continue
    if start <= instant <= finish:
        events.append(line)
clock = []
for record in records:
    elapsed = (parse(record['finished_at']) - parse(record['started_at'])).total_seconds()
    gap = elapsed - record['active_host_seconds']
    clock.append({'stage': record['stage'], 'elapsed_wall_seconds': elapsed,
                  'active_host_seconds': record['active_host_seconds'], 'clock_difference_seconds': gap,
                  'within_two_seconds': abs(gap) <= 2})
result = {'started_at': start.isoformat(), 'finished_at': finish.isoformat(), 'power_events': events,
          'clock_checks': clock, 'no_host_sleep_observed': not events,
          'host_continuity_gate_passed': not events and all(row['within_two_seconds'] for row in clock),
          'scope': 'Whole confirmation interval, including the transition between the two sequential emulator workers; does not alter or exclude any trial.'}
with (ROOT / 'host-awake-assessment.json').open('x') as stream:
    stream.write(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
