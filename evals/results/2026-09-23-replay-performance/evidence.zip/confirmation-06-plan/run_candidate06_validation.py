"""Sequential, frozen device validation. No model/agent execution."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/private/tmp/minimap-performance-20260922')
PLAN = ROOT / 'confirmation-06-plan'
HARNESS = PLAN / 'harness'
STATE = ROOT / 'STATE.json'
MANIFEST = json.loads((PLAN / 'manifest.json').read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(ROOT / 'candidate-06/minimap') == MANIFEST['candidate_sha256']
assert sha(ROOT / 'baseline/minimap') == MANIFEST['baseline_sha256']
for name, expected in MANIFEST['harness_sha256'].items():
    assert sha(HARNESS / name) == expected
assert sha(ROOT / 'trace_drawer_stability.py') == MANIFEST['diagnostic_sha256']
assert not (PLAN / 'execution.json').exists(), 'Do not overwrite an earlier attempt'
ledger = []


def state_update(**fields):
    data = json.loads(STATE.read_text())
    data.update(fields)
    STATE.write_text(json.dumps(data, indent=2) + '\n')


def run(name, arguments):
    state_update(candidate06_stage=name, candidate06_batch_running=True)
    record = {'stage': name, 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'argv': [sys.executable, '-u', *map(str, arguments)]}
    print(json.dumps({'starting': name}), flush=True)
    with (PLAN / (name + '.log')).open('x') as log:
        process = subprocess.Popen(record['argv'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        for line in process.stdout:
            log.write(line)
            log.flush()
            print(line, end='', flush=True)
        record['exit_code'] = process.wait()
    record['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    ledger.append(record)
    (PLAN / 'execution.json').write_text(json.dumps(ledger, indent=2) + '\n')
    return record['exit_code']


def paired_arguments(stage, device):
    return [HARNESS / 'replay_performance.py', '--baseline', ROOT / 'baseline/minimap',
            '--candidate', ROOT / 'candidate-06/minimap', '--apks', ROOT / 'apks',
            '--output', ROOT / f'{stage}-06-api{device["api"]}', '--serial', device['serial'],
            '--stage', stage, '--repetitions', '10' if stage == 'confirmation' else '1',
            '--order-offset', str(device['order_offset'])]


def main():
    print('Waiting for the original frozen cohort to finish; no second device worker is active.', flush=True)
    while json.loads(STATE.read_text()).get('batch_running'):
        time.sleep(30)
    original = json.loads((ROOT / 'confirmation-summary.json').read_text())
    assert original['recorded_trials'] == original['planned_trials'] == 180
    try:
        assert run('drawer-diagnostic', [ROOT / 'trace_drawer_stability.py']) == 0
        for device in MANIFEST['apis']:
            assert run(f'pilot-api{device["api"]}', paired_arguments('pilot', device)) == 0
        for device in MANIFEST['apis']:
            assert run(f'controls-api{device["api"]}', [HARNESS / 'controlled_contracts.py',
                '--binary', ROOT / 'candidate-06/minimap', '--apks', ROOT / 'recovery-fixtures/apks',
                '--paired-run', ROOT / f'pilot-06-api{device["api"]}',
                '--output', ROOT / f'controls-06-api{device["api"]}', '--serial', device['serial']]) == 0
        # Always finish all registered confirmation assignments, even if a trial fails.
        for device in MANIFEST['apis']:
            run(f'confirmation-api{device["api"]}', paired_arguments('confirmation', device))
        assert run('analysis', [HARNESS / 'analyze_replay.py',
            ROOT / 'confirmation-06-api36/results.json', ROOT / 'confirmation-06-api37/results.json',
            '--output', ROOT / 'confirmation-06-summary.json']) == 0
        state_update(candidate06_validation_complete=True)
    finally:
        state_update(candidate06_batch_running=False)


if __name__ == '__main__':
    main()
